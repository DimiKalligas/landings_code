import DynamicCrudPage from "@/app/admin/components/DynamicCrudPage";
import { getModelMetadata, getDisplayName } from "@/app/admin/lib/schema-introspection";

interface PageProps {
  params: Promise<{
    model: string;
  }>;
}

export default async function ModelPage({ params }: PageProps) {
  const { model } = await params;
  const metadata = await getModelMetadata(model);

  if (!metadata) {
    return (
      <div className="p-8">
        <h1 className="text-4xl font-bold text-red-600">Model not found</h1>
        <p className="text-gray-600 mt-2">The model "{model}" does not exist in your schema.</p>
      </div>
    );
  }

  return (
    <DynamicCrudPage
      model={model}
      displayName={getDisplayName(model)}
      fields={metadata.fields}
    />
  );
}

// Optional: Generate static params for better performance
export async function generateStaticParams() {
  const { listAllModels } = await import("@/app/admin/lib/schema-introspection");
  const models = await listAllModels();

  return models.map((model) => ({
    model: model.toLowerCase(),
  }));
}
