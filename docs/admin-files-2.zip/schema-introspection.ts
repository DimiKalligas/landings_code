/**
 * Prisma Schema Introspection Utility
 * Extracts model information from your Prisma schema
 * 
 * This uses Prisma's built-in introspection to automatically
 * discover all your models and their fields without manual definition
 */

import { PrismaClient, Prisma } from "@prisma/client";

export interface ModelField {
  name: string;
  type: string;
  isRequired: boolean;
  isList: boolean;
  isRelation: boolean;
  kind?: string;
}

export interface ModelMetadata {
  name: string;
  displayName: string;
  fields: ModelField[];
}

let cachedModels: Map<string, ModelMetadata> | null = null;

/**
 * Get all Prisma models and their metadata
 * Automatically extracts from your prisma schema
 */
export async function getPrismaModels(): Promise<Map<string, ModelMetadata>> {
  // Return cached version if available
  if (cachedModels) {
    return cachedModels;
  }

  try {
    // Get the Prisma DMMF (Data Model Meta Format)
    const prismaClient = new PrismaClient();
    const dmmf = Prisma.dmmf;

    const models = new Map<string, ModelMetadata>();

    // Iterate through all models defined in your schema
    dmmf.datamodel.models.forEach((model) => {
      const fields: ModelField[] = model.fields.map((field) => ({
        name: field.name,
        type: field.type,
        isRequired: field.isRequired,
        isList: field.isList,
        isRelation: field.kind === "object",
        kind: field.kind,
      }));

      models.set(model.name, {
        name: model.name,
        displayName: pluralizeModelName(model.name),
        fields,
      });
    });

    cachedModels = models;
    return models;
  } catch (error) {
    console.error("Error loading Prisma models:", error);
    return new Map();
  }
}

/**
 * Get metadata for a specific model
 */
export async function getModelMetadata(modelName: string): Promise<ModelMetadata | null> {
  const models = await getPrismaModels();
  return models.get(modelName) || null;
}

/**
 * Get all available models (names only)
 */
export async function listAllModels(): Promise<string[]> {
  const models = await getPrismaModels();
  return Array.from(models.keys());
}

/**
 * Check if a model exists
 */
export async function modelExists(modelName: string): Promise<boolean> {
  const models = await getPrismaModels();
  return models.has(modelName);
}

/**
 * Get editable fields for a model (excludes relations and ID)
 */
export async function getEditableFields(modelName: string): Promise<ModelField[]> {
  const model = await getModelMetadata(modelName);
  if (!model) return [];

  return model.fields.filter(
    (f) => !f.isRelation && f.name !== "id" && f.name !== "createdAt" && f.name !== "updatedAt"
  );
}

/**
 * Get displayable fields for table (first 4, no relations)
 */
export async function getTableFields(modelName: string): Promise<ModelField[]> {
  const model = await getModelMetadata(modelName);
  if (!model) return [];

  return model.fields
    .filter((f) => !f.isRelation && !f.isList)
    .slice(0, 4);
}

/**
 * Pluralize model name for display
 * e.g., "user" -> "Users", "account" -> "Accounts"
 */
function pluralizeModelName(name: string): string {
  const plural = name.endsWith("y") ? name.slice(0, -1) + "ies" : name + "s";
  return plural.charAt(0).toUpperCase() + plural.slice(1);
}

/**
 * Get display name for a model
 */
export function getDisplayName(modelName: string): string {
  return pluralizeModelName(modelName);
}

/**
 * Get all non-auth models (exclude user, account, session, verification)
 * Useful for filtering to only show business domain models
 */
export async function getBusinessModels(): Promise<ModelMetadata[]> {
  const models = await getPrismaModels();
  const authModels = ["user", "account", "session", "verification"];

  return Array.from(models.values()).filter(
    (m) => !authModels.includes(m.name.toLowerCase())
  );
}
