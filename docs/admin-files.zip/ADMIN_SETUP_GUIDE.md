# Custom Admin Dashboard Implementation Guide

## Overview
This is a lightweight, custom admin dashboard built with Next.js App Router, React, and Prisma ORM. It handles CRUD operations for all your database models without relying on third-party admin tools.

## File Structure

```
app/
├── admin/
│   ├── layout.tsx           # Main admin layout with sidebar
│   ├── page.tsx             # Dashboard home
│   ├── actions.ts           # Server actions for CRUD
│   ├── components/
│   │   └── CrudPage.tsx     # Reusable CRUD component
│   └── [model]/
│       ├── page.tsx         # Individual model pages
│       ├── accounts/
│       ├── users/
│       ├── sessions/
│       ├── countries/
│       ├── manufacturers/
│       ├── models/
│       └── types/
```

## Installation Steps

### 1. Copy Files to Your Project

The following files need to be created in your Next.js project:

**Core Files:**
- `app/admin/layout.tsx` - Main layout with navigation
- `app/admin/page.tsx` - Dashboard home page
- `app/admin/actions.ts` - Server actions (move to this path from admin-actions.ts)
- `app/admin/components/CrudPage.tsx` - Reusable CRUD component

**Example Pages** (customize as needed):
- `app/admin/users/page.tsx` - Users management
- `app/admin/accounts/page.tsx` - Accounts management
- `app/admin/sessions/page.tsx` - Sessions management
- `app/admin/countries/page.tsx` - Countries management
- `app/admin/manufacturers/page.tsx` - Manufacturers management
- `app/admin/models/page.tsx` - Aircraft models
- `app/admin/types/page.tsx` - Aircraft types

### 2. Make sure you have the required dependencies

```bash
npm install lucide-react
# If you don't have Tailwind CSS configured, install it:
npm install -D tailwindcss postcss autoprefixer
npx tailwindcss init -p
```

### 3. Verify Tailwind is configured in your project

Your `tailwind.config.js` should include the app directory:
```javascript
module.exports = {
  content: [
    "./app/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
```

### 4. Add the Prisma import path

Make sure your `@/lib/prisma` is correctly set up. It should be a singleton instance:

```typescript
// lib/prisma.ts
import { PrismaClient } from '@prisma/client'

const globalForPrisma = global as unknown as { prisma: PrismaClient }

export const prisma =
  globalForPrisma.prisma ||
  new PrismaClient()

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = prisma

export default prisma
```

### 5. Access the admin dashboard

Start your development server:
```bash
npm run dev
```

Visit: `http://localhost:3000/admin`

## How to Create Pages for Other Models

To add a new model to your admin dashboard, create a page like this:

```typescript
// app/admin/[model-name]/page.tsx
import CrudPage from '@/app/admin/components/CrudPage';

export default function ModelPage() {
  return (
    <CrudPage
      model="modelName"
      title="Model Display Name"
      fields={[
        { name: 'fieldName', label: 'Field Label', type: 'text', required: true },
        { name: 'email', label: 'Email', type: 'email' },
        { name: 'count', label: 'Count', type: 'number' },
        { name: 'description', label: 'Description', type: 'textarea' },
        { 
          name: 'status', 
          label: 'Status', 
          type: 'select',
          options: [
            { value: 'active', label: 'Active' },
            { value: 'inactive', label: 'Inactive' },
          ]
        },
      ]}
    />
  );
}
```

## Field Types

The CrudPage component supports these field types:
- `text` - Simple text input
- `email` - Email input with validation
- `number` - Numeric input
- `textarea` - Multi-line text input
- `select` - Dropdown select (requires `options` array)

## Server Actions (CRUD Operations)

All CRUD operations are handled by server actions in `app/admin/actions.ts`:

- `getRecords(model, skip, take)` - Fetch paginated records
- `getRecord(model, id)` - Fetch a single record
- `createRecord(model, data)` - Create a new record
- `updateRecord(model, id, data)` - Update a record
- `deleteRecord(model, id)` - Delete a record
- `getAllUsers()` - Special function to get users with relations

## Features

✅ **CRUD Operations** - Create, read, update, delete for all models
✅ **Pagination** - Built-in pagination with 10 items per page
✅ **Search & Filter** - Search across fields (easily customizable)
✅ **Responsive Design** - Works on desktop and mobile
✅ **Error Handling** - User-friendly error messages
✅ **Loading States** - Visual feedback during operations
✅ **Tailwind CSS** - Styled with Tailwind utilities
✅ **Type Safety** - Works with TypeScript

## Adding Authentication

To protect your admin routes, you can add middleware. Create `middleware.ts` in your project root:

```typescript
import { NextRequest, NextResponse } from 'next/server'
import { auth } from '@/lib/auth' // Your better-auth instance

export async function middleware(request: NextRequest) {
  if (request.nextUrl.pathname.startsWith('/admin')) {
    const session = await auth()
    
    if (!session?.user || session.user.role !== 'admin') {
      return NextResponse.redirect(new URL('/login', request.url))
    }
  }
  
  return NextResponse.next()
}

export const config = {
  matcher: ['/admin/:path*'],
}
```

## Customization

### Change Sidebar Navigation

Edit `app/admin/layout.tsx` to customize the navigation links based on your models.

### Change Colors

The dashboard uses Tailwind CSS classes. Common color customizations:
- `bg-blue-600` → Change button colors
- `bg-slate-900` → Change sidebar background
- Update `tailwind.config.js` for global color changes

### Add More Fields to Models

In each model's page, simply add more field definitions to the `fields` array in the CrudPage component.

### Customize Dashboard Stats

Edit `app/admin/page.tsx` to add different metrics and charts.

## Troubleshooting

**Issue: "Cannot find module '@/lib/prisma'"**
- Make sure your Prisma client is exported from `lib/prisma.ts`
- Update the import path in `actions.ts` if needed

**Issue: Fields not showing in forms**
- Check that field names match your Prisma schema exactly
- Field names are case-sensitive

**Issue: Tailwind styles not applying**
- Make sure `tailwind.config.js` includes `"./app/**/*.{js,ts,jsx,tsx}"`
- Restart your dev server after Tailwind config changes

## Next Steps

1. **Add Authentication Guard** - Use the middleware example above
2. **Add Validation** - Add form validation in the CrudPage component
3. **Add Search** - Enhance server actions to support search
4. **Add Filters** - Add filtering to the CrudPage component
5. **Add Bulk Operations** - Add bulk delete/update functionality
6. **Add Exports** - Export data to CSV/Excel

## Support

For issues with Prisma ORM, visit: https://www.prisma.io/docs
For Tailwind CSS docs: https://tailwindcss.com/docs
For Next.js App Router: https://nextjs.org/docs/app
