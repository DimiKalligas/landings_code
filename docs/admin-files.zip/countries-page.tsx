import CrudPage from '@/app/admin/components/CrudPage';

export default function CountriesPage() {
  return (
    <CrudPage
      model="country"
      title="Countries"
      fields={[
        { name: 'iso_3166_code', label: 'ISO Code', type: 'text' },
        { name: 'country_name', label: 'Country Name', type: 'text' },
        { name: 'continent', label: 'Continent', type: 'text' },
        { name: 'flag_url', label: 'Flag URL', type: 'text' },
        { name: 'wikipedia_link', label: 'Wikipedia Link', type: 'text' },
      ]}
    />
  );
}
