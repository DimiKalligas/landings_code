import CrudPage from '@/app/admin/components/CrudPage';

export default function AccountsPage() {
  return (
    <CrudPage
      model="account"
      title="Accounts"
      fields={[
        { name: 'accountId', label: 'Account ID', type: 'text', required: true },
        { name: 'providerId', label: 'Provider ID', type: 'text', required: true },
        { name: 'provider', label: 'Provider', type: 'text' },
        { name: 'type', label: 'Type', type: 'text' },
        { name: 'providerAccountId', label: 'Provider Account ID', type: 'text' },
        { name: 'scope', label: 'Scope', type: 'text' },
      ]}
    />
  );
}
